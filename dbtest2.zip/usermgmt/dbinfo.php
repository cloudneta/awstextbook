<?php
define('DB_SERVER', '10.1.2.10');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'qwe123');
define('DB_DATABASE', 'sqlDB');
?>